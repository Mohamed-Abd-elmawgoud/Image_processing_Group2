#!/usr/bin/env python3
"""
esp_bridge_node.py
ROS2 Jazzy node that:
  1. Subscribes to /ackermann/cmd  [steering_angle, throttle]
  2. Converts to PWM / servo values
  3. Sends a compact binary or ASCII frame to the ESP over UART/USB-Serial

Wire-up:
  Pi GPIO 14 (TXD) → ESP RX   (or use a USB-to-Serial adapter → /dev/ttyUSB0)
  Pi GPIO 15 (RXD) → ESP TX
  Common GND

ESP firmware (Arduino/ESP-IDF) must parse the same packet format used here.
A matching Arduino sketch is printed in the docstring of _build_packet().
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import serial
import struct


class EspBridgeNode(Node):
    def __init__(self):
        super().__init__('esp_bridge_node')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('serial_port',  '/dev/ttyUSB0')   # or /dev/ttyAMA0
        self.declare_parameter('baud_rate',    115200)
        self.declare_parameter('timeout',      0.1)

        # Steering servo PWM range (µs) – adjust to your servo
        self.declare_parameter('steer_mid_us',  1500)
        self.declare_parameter('steer_range_us', 400)   # ±400 µs around mid

        # Throttle ESC range (µs)
        self.declare_parameter('throttle_min_us', 1000)
        self.declare_parameter('throttle_max_us', 2000)

        port    = self.get_parameter('serial_port').value
        baud    = self.get_parameter('baud_rate').value
        timeout = self.get_parameter('timeout').value

        self.steer_mid    = self.get_parameter('steer_mid_us').value
        self.steer_range  = self.get_parameter('steer_range_us').value
        self.thr_min      = self.get_parameter('throttle_min_us').value
        self.thr_max      = self.get_parameter('throttle_max_us').value

        # ── Serial port ───────────────────────────────────────────────────
        try:
            self.ser = serial.Serial(port, baud, timeout=timeout)
            self.get_logger().info(f'Serial open: {port} @ {baud}')
        except serial.SerialException as e:
            self.get_logger().error(f'Cannot open serial port {port}: {e}')
            raise

        # ── ROS subscriber ────────────────────────────────────────────────
        self.sub = self.create_subscription(
            Float32MultiArray,
            '/ackermann/cmd',
            self.cmd_callback,
            10
        )

        # Safety: send stop on startup
        self._send(0.0, 0.0)
        self.get_logger().info('EspBridgeNode ready')

    # ── Callback ──────────────────────────────────────────────────────────
    def cmd_callback(self, msg: Float32MultiArray):
        if len(msg.data) < 2:
            self.get_logger().warn('cmd message has fewer than 2 elements')
            return
        steering = float(msg.data[0])   # −1 … +1
        throttle = float(msg.data[1])   #  0 … +1
        self._send(steering, throttle)

    # ── Conversion + transmission ─────────────────────────────────────────
    def _send(self, steering: float, throttle: float):
        # Clamp inputs
        steering = max(-1.0, min(1.0, steering))
        throttle = max( 0.0, min(1.0, throttle))

        # Convert to PWM microseconds
        steer_us = int(self.steer_mid + steering * self.steer_range)
        thr_us   = int(self.thr_min  + throttle * (self.thr_max - self.thr_min))

        packet = self._build_packet(steer_us, thr_us)
        try:
            self.ser.write(packet)
        except serial.SerialException as e:
            self.get_logger().error(f'Serial write error: {e}')

        self.get_logger().debug(f'TX steer_us={steer_us}  thr_us={thr_us}')

    @staticmethod
    def _build_packet(steer_us: int, thr_us: int) -> bytes:
        """
        Binary packet format (8 bytes):
          [0]    0xAA  – start byte
          [1]    0x55  – start byte
          [2-3]  uint16 little-endian – steering PWM (µs)
          [4-5]  uint16 little-endian – throttle  PWM (µs)
          [6]    uint8  – XOR checksum of bytes [2-5]
          [7]    0x0A  – newline / end marker

        Matching Arduino (ESP32) receiver sketch:
        ─────────────────────────────────────────
        #define STEER_PIN  18
        #define THROTTLE_PIN 19

        #include <ESP32Servo.h>
        Servo steerServo, throttleESC;

        uint8_t buf[8];
        uint8_t idx = 0;

        void setup() {
          Serial.begin(115200);
          steerServo.attach(STEER_PIN);
          throttleESC.attach(THROTTLE_PIN);
          throttleESC.writeMicroseconds(1500); // arm ESC
          delay(2000);
        }

        void loop() {
          while (Serial.available()) {
            uint8_t b = Serial.read();
            if (idx == 0 && b != 0xAA) return;
            if (idx == 1 && b != 0x55) { idx=0; return; }
            buf[idx++] = b;
            if (idx == 8) {
              idx = 0;
              // Verify checksum
              uint8_t csum = buf[2]^buf[3]^buf[4]^buf[5];
              if (csum != buf[6]) return;
              uint16_t steer_us = buf[2] | (buf[3]<<8);
              uint16_t thr_us   = buf[4] | (buf[5]<<8);
              steerServo.writeMicroseconds(steer_us);
              throttleESC.writeMicroseconds(thr_us);
            }
          }
        }
        ─────────────────────────────────────────
        """
        s_lo = steer_us & 0xFF
        s_hi = (steer_us >> 8) & 0xFF
        t_lo = thr_us & 0xFF
        t_hi = (thr_us >> 8) & 0xFF
        checksum = s_lo ^ s_hi ^ t_lo ^ t_hi
        return bytes([0xAA, 0x55, s_lo, s_hi, t_lo, t_hi, checksum, 0x0A])

    def destroy_node(self):
        try:
            self._send(0.0, 0.0)   # stop motors on shutdown
            self.ser.close()
        except Exception:
            pass
        super().destroy_node()


# ── Entry point ────────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = EspBridgeNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
