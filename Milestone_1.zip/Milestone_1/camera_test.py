import cv2
import time

def capture_robust():
    # Force the V4L2 backend
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)

    if not cap.isOpened():
        print("Error: Could not open /dev/video0")
        return

    # 1. Force MJPG format (More reliable for Pi Cameras on Ubuntu)
    cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
    
    # 2. Set resolution
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    print("Camera initialized. Waiting for sensor...")
    time.sleep(2) # Give it a solid 2 seconds to wake up

    # 3. Try to grab 10 frames to clear the buffer
    for i in range(10):
        success, _ = cap.read()
        if not success:
            print(f"Frame {i} grab failed, retrying...")
            time.sleep(0.1)

    # 4. The Final Grab
    ret, frame = cap.read()

    if ret and frame is not None:
        cv2.imwrite("final_working_photo.jpg", frame)
        print("SUCCESS! Image saved as final_working_photo.jpg")
    else:
        print("ERROR: Still failed to grab frame.")
        print("Try running: 'v4l2-ctl --list-devices' to check if the camera is busy.")

    cap.release()

if __name__ == "__main__":
    capture_robust()