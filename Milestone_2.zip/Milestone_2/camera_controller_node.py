#!/usr/bin/env python3
"""
camera_controller_node.py
ROS2 Jazzy node that:
  1. Captures frames from the Pi Camera (via OpenCV / libcamera)
  2. Extracts image features (brightness, contrast, etc.)
  3. Computes Ackermann steering + throttle commands
  4. Publishes commands to a topic consumed by the ESP bridge node
"""

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float32MultiArray
from cv_bridge import CvBridge
import cv2
import numpy as np


class CameraControllerNode(Node):
    def __init__(self):
        super().__init__('camera_controller_node')

        # ── Parameters (override via YAML or CLI) ──────────────────────────
        self.declare_parameter('camera_index', 0)       # /dev/video0 for Pi Camera
        self.declare_parameter('frame_width',  640)
        self.declare_parameter('frame_height', 480)
        self.declare_parameter('fps',          30)
        self.declare_parameter('publish_image', True)   # set False to save bandwidth

        cam_idx    = self.get_parameter('camera_index').value
        width      = self.get_parameter('frame_width').value
        height     = self.get_parameter('frame_height').value
        fps        = self.get_parameter('fps').value
        self.pub_img = self.get_parameter('publish_image').value

        # ── OpenCV capture ─────────────────────────────────────────────────
        # For Pi Camera Module v2/v3 on Bullseye/Bookworm use:
        #   cv2.VideoCapture("libcamerasrc ! video/x-raw,width=640,height=480,
        #                     framerate=30/1 ! videoconvert ! appsink", cv2.CAP_GSTREAMER)
        # For simplicity we use the V4L2 device node:
        self.cap = cv2.VideoCapture(cam_idx)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        self.cap.set(cv2.CAP_PROP_FPS,          fps)

        if not self.cap.isOpened():
            self.get_logger().error('Cannot open camera – check camera_index parameter')
            raise RuntimeError('Camera not available')

        # ── ROS interfaces ─────────────────────────────────────────────────
        self.bridge = CvBridge()

        # Publishes raw frame (optional, useful for rviz2 / debugging)
        self.image_pub = self.create_publisher(Image, '/camera/image_raw', 10)

        # Publishes [steering_angle, throttle] – consumed by esp_bridge_node
        # steering_angle : -1.0 (full left) … +1.0 (full right)
        # throttle       :  0.0 (stop)      …  1.0 (full forward)
        self.cmd_pub = self.create_publisher(Float32MultiArray, '/ackermann/cmd', 10)

        # ── Timer drives the control loop ──────────────────────────────────
        self.timer = self.create_timer(1.0 / fps, self.control_loop)
        self.get_logger().info('CameraControllerNode started')

    # ── Main loop ──────────────────────────────────────────────────────────
    def control_loop(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn('Dropped frame')
            return

        # 1. Publish raw image if enabled
        if self.pub_img:
            ros_img = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
            ros_img.header.stamp = self.get_clock().now().to_msg()
            ros_img.header.frame_id = 'camera_link'
            self.image_pub.publish(ros_img)

        # 2. Extract features
        features = self.extract_features(frame)

        # 3. Compute Ackermann commands from features
        steering, throttle = self.compute_commands(features, frame)

        # 4. Publish command
        cmd_msg = Float32MultiArray()
        cmd_msg.data = [float(steering), float(throttle)]
        self.cmd_pub.publish(cmd_msg)

        self.get_logger().debug(
            f'brightness={features["brightness"]:.1f}  '
            f'steering={steering:.3f}  throttle={throttle:.3f}'
        )

    # ── Feature extraction ─────────────────────────────────────────────────
    def extract_features(self, frame: np.ndarray) -> dict:
        """
        Returns a dict of scalar image features.
        Extend this method with your own features.
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # --- Global brightness (mean pixel intensity, 0–255) ---------------
        brightness = float(np.mean(gray))

        # --- Contrast (standard deviation of pixel intensity) --------------
        contrast = float(np.std(gray))

        # --- Left / Right brightness split (useful for line following) -----
        h, w = gray.shape
        left_brightness  = float(np.mean(gray[:, : w // 2]))
        right_brightness = float(np.mean(gray[:, w // 2 :]))

        # --- Edge density (Canny) ------------------------------------------
        edges      = cv2.Canny(gray, 50, 150)
        edge_density = float(np.mean(edges) / 255.0)   # 0–1

        # --- Center-of-mass horizontal offset (−1 left … +1 right) --------
        # Useful if you threshold the image to isolate a line/object
        _, binary = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY_INV)
        moments   = cv2.moments(binary)
        if moments['m00'] > 0:
            cx = moments['m10'] / moments['m00']
            com_offset = (cx - w / 2.0) / (w / 2.0)   # normalised
        else:
            com_offset = 0.0

        return {
            'brightness':       brightness,
            'contrast':         contrast,
            'left_brightness':  left_brightness,
            'right_brightness': right_brightness,
            'edge_density':     edge_density,
            'com_offset':       com_offset,
        }

    # ── Command computation ────────────────────────────────────────────────
    def compute_commands(self, features: dict, frame: np.ndarray):
        """
        Map image features → (steering_angle, throttle).

        Replace / extend the logic below with your own algorithm
        (PID controller, neural network, rule-based FSM, etc.)

        steering_angle : -1.0 … +1.0
        throttle       :  0.0 … +1.0
        """
        # ── Example: line-following via center-of-mass offset ──────────────
        # Proportional steering: steer toward where the line centre is
        steering = float(np.clip(features['com_offset'] * 1.5, -1.0, 1.0))

        # ── Example: slow down when scene is very dark or very bright ──────
        brightness = features['brightness']
        if brightness < 30 or brightness > 230:
            throttle = 0.0                  # stop in extreme lighting
        else:
            # Normalise mid-range brightness → speed  (tweak as needed)
            throttle = float(np.clip(0.4 + features['edge_density'] * 0.3, 0.0, 1.0))

        return steering, throttle

    def destroy_node(self):
        self.cap.release()
        super().destroy_node()


# ── Entry point ────────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = CameraControllerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
